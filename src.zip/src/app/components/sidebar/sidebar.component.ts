import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { AuthService } from '../../services/auth/auth.service';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, TranslateModule],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss',
})
export class SidebarComponent implements OnInit {

  private readonly router      = inject(Router);
  private readonly authService = inject(AuthService);

  appName    = 'ScholarTik';
  appTagline = 'Bourses · Visas · Commerce';

  // Exposer les signals directement au template
  currentUser  = this.authService.currentUser;
  userFullName = this.authService.userFullName;

  get userInitials(): string {
    const name = this.userFullName();
    if (!name.trim()) return 'AD';
    return name
      .split(' ')
      .slice(0, 2)
      .map(p => p.charAt(0).toUpperCase())
      .join('');
  }

  get userEmail(): string {
    return this.currentUser()?.email ?? '';
  }

  get userRole(): string {
    return this.currentUser()?.role ?? '';
  }

  ngOnInit(): void {}

  handleLogout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}