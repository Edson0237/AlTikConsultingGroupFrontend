import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth/auth.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
})
export class HeaderComponent implements OnInit {

  private readonly router      = inject(Router);
  private readonly authService = inject(AuthService);

  // UI state
  showUserMenu = false;
  currentLang  = 'FR';
  searchQuery  = '';
  unreadCount  = 3;

  // Signals exposés au template
  currentUser  = this.authService.currentUser;
  userFullName = this.authService.userFullName;

  get userInitials(): string {
    const name = this.userFullName();
    if (!name.trim()) return 'AD';
    return name
      .split(' ')
      .slice(0, 2)
      .map(p => p.charAt(0).toUpperCase())
      .join('');
  }

  get userName(): string {
    return this.userFullName() || 'Utilisateur';
  }

  get userEmail(): string {
    return this.currentUser()?.email ?? '';
  }

  ngOnInit(): void {}

  toggleLanguage(): void {
    this.currentLang = this.currentLang === 'FR' ? 'EN' : 'FR';
    // this.translateService.use(this.currentLang.toLowerCase());
  }

  toggleNotifications(): void {
    this.router.navigate(['/notifications']);
  }

  toggleUserMenu(): void {
    this.showUserMenu = !this.showUserMenu;
  }

  closeUserMenu(): void {
    this.showUserMenu = false;
  }

  goToProfile(): void {
    this.closeUserMenu();
    this.router.navigate(['/dashboard-admin/parametres']);
  }

  handleLogout(): void {
    this.closeUserMenu();
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}